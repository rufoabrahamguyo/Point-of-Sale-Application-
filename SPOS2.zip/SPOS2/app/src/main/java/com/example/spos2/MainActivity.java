package com.example.spos2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Item quantities
    int qtyBread = 0, qtyMilk = 0, qtySugar = 0, qtyTissue = 0;

    // Prices for each item
    int priceBread = 50, priceMilk = 40, priceSugar = 30, priceTissue = 60;

    // Buttons
    private Button btnBread, btnMilk, btnSugar, btnTissue;

    // Views for quantities and totals
    private EditText etBreadQnty, etMilkQnty, etSugarQnty, etTissueQnty;
    private EditText etBreadTotal, etMilkTotal, etSugarTotal, etTissueTotal;

    // Grand total view
    private TextView tvGrandTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons
        btnBread = findViewById(R.id.btnBread);
        btnMilk = findViewById(R.id.btnMilk);
        btnSugar = findViewById(R.id.btnSugar);
        btnTissue = findViewById(R.id.btnTissue);

        // Initialize EditTexts
        etBreadQnty = findViewById(R.id.etBreadQnty);
        etMilkQnty = findViewById(R.id.etMilkQnty);
        etSugarQnty = findViewById(R.id.etSugarQnty);
        etTissueQnty = findViewById(R.id.etTissueQnty);

        etBreadTotal = findViewById(R.id.etBreadTotal);
        etMilkTotal = findViewById(R.id.etMilkTotal);
        etSugarTotal = findViewById(R.id.etSugarTotal);
        etTissueTotal = findViewById(R.id.etTissueTotal);

        // Initialize Grand Total TextView
        tvGrandTotal = findViewById(R.id.tvGrandTotal);

        // Set click listeners
        btnBread.setOnClickListener(v -> {
            qtyBread++;
            updateItem(qtyBread, priceBread, etBreadQnty, etBreadTotal);
            updateGrandTotal();
        });

        btnMilk.setOnClickListener(v -> {
            qtyMilk++;
            updateItem(qtyMilk, priceMilk, etMilkQnty, etMilkTotal);
            updateGrandTotal();
        });

        btnSugar.setOnClickListener(v -> {
            qtySugar++;
            updateItem(qtySugar, priceSugar, etSugarQnty, etSugarTotal);
            updateGrandTotal();
        });

        btnTissue.setOnClickListener(v -> {
            qtyTissue++;
            updateItem(qtyTissue, priceTissue, etTissueQnty, etTissueTotal);
            updateGrandTotal();
        });
    }

    private void updateItem(int qty, int price, EditText qtyView, EditText totalView) {
        qtyView.setText(String.valueOf(qty));
        totalView.setText(String.valueOf(qty * price));
    }

    private void updateGrandTotal() {
        int grandTotal = (qtyBread * priceBread) + (qtyMilk * priceMilk)
                + (qtySugar * priceSugar) + (qtyTissue * priceTissue);
        tvGrandTotal.setText(String.valueOf(grandTotal));
    }
}
